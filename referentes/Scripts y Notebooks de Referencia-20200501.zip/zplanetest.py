#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 09:48:11 2018

@author: andres
"""

from zplane import zplane

zplane([-1],[0,0],filename='none')