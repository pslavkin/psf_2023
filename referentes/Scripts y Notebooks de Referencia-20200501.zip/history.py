# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Tue Feb 27 08:58:22 2018)---
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')

## ---(Tue Feb 27 09:01:13 2018)---
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
%clear
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
debugfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
%clear
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/aliasing.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/dog.py', wdir='/root/.config/spyder-py3')
debugfile('/root/.config/spyder-py3/dog.py', wdir='/root/.config/spyder-py3')
debugfile('/root/.config/spyder-py3/dog.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/dog.py', wdir='/root/.config/spyder-py3')
1
0
runfile('/root/.config/spyder-py3/dog.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/looptest.py', wdir='/root/.config/spyder-py3')
%clear

## ---(Wed Feb 28 16:39:48 2018)---
runfile('/root/.config/spyder-py3/aliasing.py', wdir='/root/.config/spyder-py3')
runfile('/home/andres/sine.py', wdir='/home/andres')
runfile('/root/.config/spyder-py3/aliasing.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/temp.py', wdir='/root/.config/spyder-py3')
runfile('/root/.config/spyder-py3/funcion.py', wdir='/root/.config/spyder-py3')
format(10,0,9)
.format(10,0,9)
.format(10,0)
format(10,0)
format('10','0')