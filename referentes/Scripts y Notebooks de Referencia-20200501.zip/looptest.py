#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 15:36:09 2018

@author: root
"""

for i in range(1,10):
    if i == 3:
        break
    print(i)
    
    
numbers = [1,10,20,30,40,50]
sum = 0
for number in numbers:
    sum = sum + number
print(sum)

counter = 0
while counter <= 100:
    print(counter)
    counter + 2
    
    